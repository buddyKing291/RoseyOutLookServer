package nmu.wrpv.rosyoutlook;

public enum UserType {
    REGULAR,INFLUENCER,ADMIN
}
