package nmu.wrpv.rosyoutlook;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.text.method.BaseKeyListener;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import static nmu.wrpv.rosyoutlook.MainActivity.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class LogInActivity extends AppCompatActivity {
    TextView error;
    EditText username;
    EditText password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        error = findViewById(R.id.logInError);
        username = findViewById(R.id.logInUsername);
        password = findViewById(R.id.logInPassword);
        /*password.setOnEditorActionListener((v,id,event)->{
            if(event.getKeyCode()== KeyEvent.KEYCODE_ENTER)
                logIN();
            return false;
        });*/
    }


    public void logIn(View view) {
        logIN();
    }
    public void logIN(){
        //query database to check
        //error.setText(username.getText()+"  "+password.getText());
        if(username.getText() == null && password.getText() == null) return;

        String usernameS = "o";
        String passwordS = "o";
        String type = "o";
        /*try{
            ResultSet result = state.executeQuery("SELECT * FROM user WHERE username='"+username.getText().toString()+"'");
            if(result == null){
                password.setText("");
                error.setText("Unable to find username");
                error.setTextColor(Color.RED);
                return;
            }
            while(result.next()){
                usernameS = result.getString("username");
                passwordS = result.getString("password");
                type = result.getString("type");
            }
        }
        catch(Exception e){
            password.setText("");
            error.setText("Internal error please try again");
            error.setTextColor(Color.RED);
            return;
        }*/
        //if(usernameS==null && passwordS==null) return;
        if(usernameS.equals(username.getText().toString()) && passwordS.equals(password.getText().toString())) {
            //set account
            finish();
        }

        //else{
        password.setText("");
        error.setText("Username and password do not match");
        error.setTextColor(Color.RED);
        //}
    }


    public void registerAccount(View view) {
        //start registerAccount activity
        finish();
    }
}