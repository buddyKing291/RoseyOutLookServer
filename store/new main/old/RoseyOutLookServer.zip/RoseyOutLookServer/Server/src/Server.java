import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.sql.DriverManager.getConnection;

public class Server {
    public Server() {
        runServer();
    }

    static Connection connect = null;
    static Statement state = null;
    public void connectToDB(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception e) {
            return;
        }

        try {
            //String connectionString = "jdbc:mysql://localhost:3306/roseyoutlook";//Junaids local instance
            String connectionString = "jdbc:mysql://aws.connect.psdb.cloud:3306/roseyoutlook";//online version no foreign keys
            //String user= "root";//Junaids local instance
            String user= "4lcfrj51pfj76shqo1ff";//online version
            //String password="lefleurking";//Junaids local
            String password="pscale_pw_NJUGeBK7JU3WKzYJSV0jO7aAxQYglYqbue6Cx1Qk4fw";//online
            connect = getConnection(connectionString, user, password);
            state = connect.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        } catch (Exception e) {
            System.out.println("why");
        }

    }
    public void runServer() {
        connectToDB();
        ServerSocket server;
        Socket connection;
        OutputStream OS;
        ObjectOutputStream OOS;
        InputStream IS;
        ObjectInputStream OIS;

        try {
            // Step 1: Create a ServerSocket.
            server = new ServerSocket(500, 100);
            System.out.println("SERVER: Server started "
                    + InetAddress.getLocalHost().getHostAddress()
            );


            while (true) {

                // Step 2: Wait for a connection.
                connection = server.accept();
                System.out.println("SERVER: Connection "
                        + " received from: "
                        + connection.getInetAddress().getHostName());
                // Step 3: Get dis and dos streams.//would here onwards also need a while?
                IS = new DataInputStream(connection.getInputStream());
                OIS = new ObjectInputStream(IS);
                Map<String, Map<String,String>> requests = (Map) OIS.readObject();
                Map<String,String> output = new HashMap<>();
                List<String> keys = new ArrayList<>(requests.keySet());
                for(int i = 0; i < keys.size();i++){
                    switch(keys.get(i)) {
                        case "login":
                            login(requests.get(keys.get(i)),output);
                            break;
                        case "friend":
                            getFriends(requests.get(keys.get(i)).get("username"),output);
                            break;
                        case "following":
                            getFollowing(requests.get(keys.get(i)).get("username"),output);
                            break;
                    }
                }

                OS = new DataOutputStream(connection.getOutputStream());
                OOS = new ObjectOutputStream(OS);
                OOS.writeObject(output);
                connection.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
        finally{
        }
    }
    public void login(Map<String,String> data, Map<String,String> output){
        try{
            ResultSet result = state.executeQuery("SELECT * FROM user WHERE username='"+data.get("username")+"' OR email='"+data.get("username")+"'");
            if(result == null){
                output = null;
                return;
            }
            while(result.next()){
                /*String username = result.getString("username");
                String email = result.getString("email");*/
                String password = result.getString("password");
                if(!password.equals(data.get("password"))){
                    output.put("error","error");
                    return;
                }
                output.put("username",result.getString("username"));
                String type = result.getString("type");
                switch(type){
                    case "PUBLIC":
                        getPublicData(output);
                        break;
                    case "INFLUENCER":
                        getInfluencerData(output);
                        break;
                    case "ADMIN":
                        getAdminData(output);
                        break;
                }
                output.put("type",type);
                Blob blob = result.getBlob("profilePic");
                byte[] bdata = blob.getBytes(1, (int) blob.length());
                output.put("image",new String(bdata));
               /* String value = (s);//how to convert back to blob in main
                byte[] buff = value.getBytes();
                Blob blob = new SerialBlob(buff);*/
            }
        }
        catch(Exception e){
            /*password.setText("");
            error.setText("Internal error please try again");
            error.setTextColor(Color.RED);*/
            return;
        }
    }
    public void getAdminData(Map<String,String> output){
        try{
            ResultSet result = state.executeQuery("SELECT * FROM admin WHERE username='"+output.get("username")+"'");
            while(result.next()){
                output.put("name",result.getString("FirstName")+" "+result.getString("Surname"));
            }
        }
        catch(Exception e){

        }
    }
    public void getPublicData(Map<String,String> output){
        try{
            ResultSet result = state.executeQuery("SELECT * FROM public WHERE username='"+output.get("username")+"'");
            while(result.next()){
                output.put("name",result.getString("prefferedName"));
                //get friends and those they follow
            }
        }
        catch(Exception e){

        }
    }
    public void getInfluencerData(Map<String,String> output){
        try{
            ResultSet result = state.executeQuery("SELECT * FROM influencer WHERE username='"+output.get("username")+"'");
            while(result.next()){
                output.put("name",result.getString("prefferedName"));
                //get friends and those they follow
            }
        }
        catch(Exception e){

        }
    }
    public void getFriends(String username, Map<String,String> output){//here
        try{
            ResultSet result = state.executeQuery("SELECT * FROM friend join  WHERE username='"+username+"' OR email='"+username+"'");
            while(result.next()){
                output.put("name",result.getString("FirstName")+" "+result.getString("Surname"));
            }
        }
        catch(Exception e){

        }
    }
    public void getFollowing(String username, Map<String,String> output){
        try{
            ResultSet result = state.executeQuery("SELECT influencer.username,influencer.prefferedName FROM following join influencer on following.InfluencerUsername = influencer.username WHERE Username='"+username+"'");
            int cur = 0;
            while(result.next()){
                output.put("username"+cur,result.getString("username"));
                output.put("name"+cur++,result.getString("prefferedName"));
            }
        }
        catch(Exception e){

        }
    }

    public static void main(String args[]) {
        new Server();
    }
}
