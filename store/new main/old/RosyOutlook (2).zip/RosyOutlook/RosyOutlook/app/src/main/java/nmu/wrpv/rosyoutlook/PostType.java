package nmu.wrpv.rosyoutlook;


public enum PostType {
    BloomingGratitude,Petal,RoseBud
}
