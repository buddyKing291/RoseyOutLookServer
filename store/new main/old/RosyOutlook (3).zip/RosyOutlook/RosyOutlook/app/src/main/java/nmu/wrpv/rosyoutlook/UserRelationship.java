package nmu.wrpv.rosyoutlook;


public enum UserRelationship {
    NONE,FRIEND,FOLLOWING,PENDING
}
